let x=5;
console.log(x)
// how to print in js

const y=6;
console.log(y);

const word="string" //string datatype
const number =1;
const float =1.1111 ;
const p =[1,2,3]; //array datatype

const firstName="Rick";
const lastName="Riordan";
const bookTitle ="Percy Jackson";

console.log(firstName+" "+lastName+" is the author of "+bookTitle);
//how to string interpolate
let strInterpolate = `${firstName} ${lastName}`;
console.log(strInterpolate);

// if (condition){}
// ekse if (conndition){}
// else

// loose condition
if(firstName === "James"){
    lastName = "Johnson"
}else if(firstName==="Rick "){
    lastName==="Riordan";
}

let stillAlive= true;
// // to declare function
function bruh(){
    console.log("rawr")
}

 bruh();

const no =[1,2,3,4,5];
for (let i=0;i<no.length;i++){
    console.log(no[i]);
}

// object
let obj={name: "Dayana" ,age:20}
// how to access
console.log(obj.name);

